<?php

namespace App\Entity;

use App\Repository\ObservationRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\HttpFoundation\File\File;
use Vich\UploaderBundle\Mapping\Annotation as Vich;

#[ORM\Entity(repositoryClass: ObservationRepository::class)]
#[Vich\Uploadable]
class Observation
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $sujet = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $date_debut = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $date_fin = null;

    #[ORM\Column(length: 255)]
    private ?string $entreprise = null;

    #[ORM\Column(length: 255)]
    private ?string $encadrent = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $binome = null;

    #[ORM\Column(length: 255)]
    private ?string $piece_a_joindre = null;
    private $updatedAt = null;
    /**
     * @Vich\UploadableField(mapping="observation_mapping", fileNameProperty="piece_a_joindre")
     * 
     */
    private $pieceAJoindreFile;

    #[ORM\Column(length: 255)]
    private ?string $nom = null;

    #[ORM\Column(length: 255)]
    private ?string $prenom = null;

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(?\DateTimeInterface $updatedAt): self
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    public function setPieceAJoindreFile(?File $pieceAJoindreFile = null): void
    {
        $this->pieceAJoindreFile = $pieceAJoindreFile;

        if (null !== $pieceAJoindreFile) {
            // Update this line to trigger Doctrine update
            $this->updatedAt = new \DateTimeImmutable();
        }
    }

    public function getPieceAJoindreFile(): ?File
    {
        return $this->pieceAJoindreFile;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSujet(): ?string
    {
        return $this->sujet;
    }

    public function setSujet(string $sujet): static
    {
        $this->sujet = $sujet;

        return $this;
    }

    public function getDateDebut(): ?\DateTimeInterface
    {
        return $this->date_debut;
    }

    public function setDateDebut(\DateTimeInterface $date_debut): static
    {
        $this->date_debut = $date_debut;

        return $this;
    }

    public function getDateFin(): ?\DateTimeInterface
    {
        return $this->date_fin;
    }

    public function setDateFin(\DateTimeInterface $date_fin): static
    {
        $this->date_fin = $date_fin;

        return $this;
    }

    public function getEntreprise(): ?string
    {
        return $this->entreprise;
    }

    public function setEntreprise(string $entreprise): static
    {
        $this->entreprise = $entreprise;

        return $this;
    }
    private $uploadDir;

    // ...

    public function setUploadDir($uploadDir)
    {
        $this->uploadDir = $uploadDir;

        return $this;
    }

    public function getUploadDir()
    {
        return $this->uploadDir;
    }
    public function getEncadrent(): ?string
    {
        return $this->encadrent;
    }

    public function setEncadrent(string $encadrent): static
    {
        $this->encadrent = $encadrent;

        return $this;
    }

    public function getBinome(): ?string
    {
        return $this->binome;
    }

    public function setBinome(?string $binome): static
    {
        $this->binome = $binome;

        return $this;
    }

    public function getPieceAJoindre(): ?string
    {
        return $this->piece_a_joindre;
    }

    public function setPieceAJoindre(string $piece_a_joindre): static
    {
        $this->piece_a_joindre = $piece_a_joindre;

        return $this;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): static
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): static
    {
        $this->prenom = $prenom;

        return $this;
    }
}
