<?php

namespace App\Controller\Admin;

use App\Entity\Observation;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractCrudController;
use EasyCorp\Bundle\EasyAdminBundle\Field\DateField;
use EasyCorp\Bundle\EasyAdminBundle\Field\Field;
use EasyCorp\Bundle\EasyAdminBundle\Field\IdField;
use EasyCorp\Bundle\EasyAdminBundle\Field\ImageField;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextEditorField;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextField;
use Vich\UploaderBundle\Form\Type\VichFileType;
use EasyCorp\Bundle\EasyAdminBundle\Field\FileField; // Import the FileField

class ObservationCrudController extends AbstractCrudController
{
    public static function getEntityFqcn(): string
    {
        return Observation::class;
    }


    public function configureFields(string $pageName): iterable
    {
        return [
            TextField::new('nom'),
            TextField::new('prenom'),
            TextField::new('sujet'),
            DateField::new('date_debut'),
            DateField::new('date_fin'),
            TextField::new('entreprise'),
            TextField::new('encadrent'),
            TextField::new('binome'),
            ImageField::new('piece_a_joindre', "Piéce a Joindre")->setUploadDir('/public/uploads/images/observations')->setBasePath($this->getParameter('app.path.observation_mapping')),

        ];
    }
}
