<?php

namespace App\Controller\Admin;

use App\Entity\Departement;
use App\Entity\Enseignant;
use App\Entity\Etudiant;
use App\Entity\Filiere;
use App\Entity\Observation;
use App\Entity\PFA;
use App\Entity\PFE;
use App\Entity\Stage;
use App\Entity\Users;
use EasyCorp\Bundle\EasyAdminBundle\Config\Dashboard;
use EasyCorp\Bundle\EasyAdminBundle\Config\MenuItem;
use EasyCorp\Bundle\EasyAdminBundle\Router\AdminUrlGenerator;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractDashboardController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class DashboardController extends AbstractDashboardController
{
    public function __construct(private AdminUrlGenerator $adminUrlGenerator)
    {
    }
    #[Route('/admin', name: 'admin')]
    public function index(): Response
    {
        $url = $this->adminUrlGenerator->setController(StageCrudController::class)->generateUrl();

        return $this->redirect($url);
    }

    public function configureDashboard(): Dashboard
    {
        return Dashboard::new()
            ->setTitle('UPF Gestion De Stage');
    }
    public function configureMenuItems(): iterable
    {
        yield MenuItem::linkToDashboard('Dashboard', 'fa fa-home');
        yield MenuItem::section('Stages');
        yield MenuItem::subMenu('Stages', 'fa-solid fa-briefcase')->setSubItems([
            MenuItem::linkToCrud('Stage', 'fas fa-user-graduate', Stage::class),
            MenuItem::linkToCrud('Stage Observation', 'fas fa-user-graduate', Observation::class),
            MenuItem::linkToCrud('Stage PFA', 'fas fa-user-graduate', PFA::class),
            MenuItem::linkToCrud('Stage PFE', 'fa-solid fa-graduation-cap', PFE::class),
        ]);
        yield MenuItem::section('ADMINISTRATION');
        yield MenuItem::subMenu('UPF', 'fas fa-school')->setSubItems([
            MenuItem::linkToCrud('Departement', 'fa-solid fa-house', Departement::class),
            MenuItem::linkToCrud('Filiere', 'fa-solid fa-graduation-cap', Filiere::class)
        ]);
        yield MenuItem::section('USERS');
        yield MenuItem::subMenu('Utilisateur', 'fa-solid fa-users')->setSubItems([
            MenuItem::linkToCrud('Encadrent Universitaire', 'fa-solid fa-chalkboard-user', Enseignant::class),
            MenuItem::linkToCrud('Etudiant', 'fa-solid fa-people-group', Etudiant::class),
            MenuItem::linkToCrud('Roles', 'fa-solid fa-people-group', Users::class)
        ]);
        // yield MenuItem::linkToCrud('The Label', 'fas fa-list', EntityClass::class);
    }
}
